document.querySelector('input[type="button"]').addEventListener('click', function() {
    // Beolvasás az űrlapról
    let szelesseg = parseFloat(document.getElementById('szelesseg').value);
    let magassag = parseFloat(document.getElementById('magassag').value);
    let papirtipus = parseFloat(document.getElementById('papirtipus').value);

    // Terület kiszámítása dm^2-ben
    let terulet = (szelesseg * magassag) / 10000; // Átváltás dm^2-re

    // Költség kiszámítása a papírtípus alapján
    let koltseg = (terulet * papirtipus).toFixed(2); // Két tizedesjegyre kerekítés

    // Eredmények megjelenítése az oldalon
    document.getElementById('terulet').textContent = terulet;
    document.getElementById('koltseg').textContent = koltseg + ' Ft';

    if (parseFloat(koltseg) > 500) {
        koltsegElement.classList.add('high-cost');
    } else {
        koltsegElement.classList.remove('high-cost');
    }
});