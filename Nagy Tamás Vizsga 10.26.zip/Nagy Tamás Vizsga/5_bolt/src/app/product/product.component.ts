import { Component } from '@angular/core';
import { ApiService } from '../services/api.service';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent {
  kepek:any;
  
  constructor(private kep:ApiService){
    this.kep.keres().subscribe(res=>{
      this.kepek=res
    })
   }
}
